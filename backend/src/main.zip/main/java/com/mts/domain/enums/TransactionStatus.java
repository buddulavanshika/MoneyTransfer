package com.mts.domain.enums;

public enum TransactionStatus {
    PENDING,
    SUCCESS,
    FAILED
}