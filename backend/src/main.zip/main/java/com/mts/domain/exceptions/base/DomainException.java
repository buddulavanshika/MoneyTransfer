package com.mts.domain.exceptions.base;

/**
 * Placeholder for DomainException (Module 2).
 */
public class DomainException {
    // TODO: implement
}
